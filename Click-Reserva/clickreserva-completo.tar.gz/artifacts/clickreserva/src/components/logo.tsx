export function Logo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="40 20 600 220"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="ClickReserva"
    >
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#2a7d4f", stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: "#1a5c38", stopOpacity: 1 }} />
        </linearGradient>
        <linearGradient id="iconBg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#3d9e68", stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: "#2a7d4f", stopOpacity: 1 }} />
        </linearGradient>
        <linearGradient id="taglineBg" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" style={{ stopColor: "#ffffff", stopOpacity: 0 }} />
          <stop offset="50%" style={{ stopColor: "#ffffff", stopOpacity: 0.08 }} />
          <stop offset="100%" style={{ stopColor: "#ffffff", stopOpacity: 0 }} />
        </linearGradient>
      </defs>

      <rect x="40" y="20" width="600" height="220" rx="28" fill="url(#bg)" />
      <circle cx="590" cy="50" r="90" fill="white" opacity="0.03" />
      <circle cx="80" cy="220" r="60" fill="white" opacity="0.03" />

      <rect x="74" y="60" width="120" height="120" rx="22" fill="url(#iconBg)" />

      <g transform="translate(88, 72)">
        <rect x="4" y="12" width="78" height="72" rx="10" fill="#4ab87a" />
        <rect x="4" y="12" width="78" height="22" rx="10" fill="#5ecc8a" />
        <rect x="4" y="26" width="78" height="8" fill="#5ecc8a" />
        <rect x="20" y="4" width="8" height="18" rx="4" fill="#b8f5d4" />
        <rect x="58" y="4" width="8" height="18" rx="4" fill="#b8f5d4" />
        <rect x="12" y="44" width="13" height="10" rx="2.5" fill="white" opacity="0.9" />
        <rect x="34" y="44" width="13" height="10" rx="2.5" fill="white" opacity="0.9" />
        <rect x="56" y="44" width="13" height="10" rx="2.5" fill="white" opacity="0.9" />
        <rect x="12" y="60" width="13" height="10" rx="2.5" fill="white" opacity="0.9" />
        <rect x="30" y="57" width="28" height="18" rx="4" fill="#b8f5d4" />
        <polygon points="58,61 68,57 68,75 58,71" fill="#b8f5d4" />
        <circle cx="39" cy="63" r="3" fill="#2a7d4f" />
      </g>

      <text x="218" y="118" fontFamily="Arial Black, Arial, sans-serif" fontSize="58" fontWeight="900" fill="white" letterSpacing="-1">Click</text>
      <text x="218" y="170" fontFamily="Arial Black, Arial, sans-serif" fontSize="58" fontWeight="900" fill="#7eedb0" letterSpacing="-1">Reserva</text>

      <rect x="74" y="188" width="556" height="36" rx="10" fill="url(#taglineBg)" />
      <text x="346" y="210" fontFamily="Arial, sans-serif" fontSize="17" fontWeight="600" fill="white" opacity="0.92" textAnchor="middle" letterSpacing="0.4">Tecnologia que organiza, escola que avança</text>
    </svg>
  );
}

import { useEffect } from "react";
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/auth-context";
import { MainLayout } from "@/components/layout/main-layout";
import { ErrorBoundary } from "@/components/error-boundary";
import { RouteErrorBoundary } from "@/components/route-error-boundary";
import { useReservationReminder } from "@/hooks/use-reservation-reminder";
import { LoginPage } from "@/pages/login";
import { DashboardPage } from "@/pages/dashboard";
import { ReservationsPage } from "@/pages/reservas/index";
import { NewReservationPage } from "@/pages/reservas/nova";
import { RoomsPage } from "@/pages/salas/index";
import { PresencePage } from "@/pages/presenca/index";
import { CoordinatorProfessorsPage } from "@/pages/coordenador/professores";
import { CoordinatorBlockedPage } from "@/pages/coordenador/bloqueios";
import { CoordinatorRoomsPage } from "@/pages/coordenador/salas";
import { CoordinatorConfigPage } from "@/pages/coordenador/configuracoes";
import { CoordinatorReservasPage } from "@/pages/coordenador/reservas";
import { FeedbackPage } from "@/pages/feedback/index";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function AuthenticatedApp() {
  const { user, isLoading } = useAuth();
  const [location, setLocation] = useLocation();

  useReservationReminder();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  useEffect(() => {
    if (!isLoading && user && user.role !== "coordinator" && user.role !== "admin") {
      const coordinatorPaths = ["/coordenador/professores", "/coordenador/bloqueios", "/coordenador/salas", "/coordenador/configuracoes", "/coordenador/reservas"];
      if (coordinatorPaths.some(p => location.startsWith(p))) {
        setLocation("/");
      }
    }
  }, [user, isLoading, location, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!user) return null;

  return (
    <MainLayout>
      <Switch>
        <Route path="/">
          <RouteErrorBoundary key="dashboard">
            <DashboardPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/reservas">
          <RouteErrorBoundary key="reservas">
            <ReservationsPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/reservas/nova">
          <RouteErrorBoundary key="nova">
            <NewReservationPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/salas">
          <RouteErrorBoundary key="salas">
            <RoomsPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/presenca">
          <RouteErrorBoundary key="presenca">
            <PresencePage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/coordenador/professores">
          <RouteErrorBoundary key="coord-professores">
            <CoordinatorProfessorsPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/coordenador/bloqueios">
          <RouteErrorBoundary key="coord-bloqueios">
            <CoordinatorBlockedPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/coordenador/salas">
          <RouteErrorBoundary key="coord-salas">
            <CoordinatorRoomsPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/coordenador/configuracoes">
          <RouteErrorBoundary key="coord-config">
            <CoordinatorConfigPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/coordenador/reservas">
          <RouteErrorBoundary key="coord-reservas">
            <CoordinatorReservasPage />
          </RouteErrorBoundary>
        </Route>
        <Route path="/feedback">
          <RouteErrorBoundary key="feedback">
            <FeedbackPage />
          </RouteErrorBoundary>
        </Route>
        <Route>
          <NotFound />
        </Route>
      </Switch>
    </MainLayout>
  );
}

function AppRoutes() {
  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route>
        <AuthenticatedApp />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AuthProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <AppRoutes />
            </WouterRouter>
          </AuthProvider>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;

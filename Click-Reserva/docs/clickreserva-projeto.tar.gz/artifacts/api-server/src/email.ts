import { Resend } from "resend";

const apiKey = process.env.RESEND_API_KEY;
const resend = apiKey ? new Resend(apiKey) : null;

const FROM_EMAIL = process.env.RESEND_FROM_EMAIL ?? "onboarding@resend.dev";

export async function sendReservationReminder(opts: {
  to: string;
  professorName: string;
  subject: string;
  roomName: string;
  date: string;
  startTime: string;
  endTime: string;
  classGroup: string;
  minutesBefore: number;
}): Promise<{ ok: boolean; error?: string }> {
  if (!resend) return { ok: false, error: "RESEND_API_KEY não configurado" };

  const label =
    opts.minutesBefore === 1 ? "1 minuto" : `${opts.minutesBefore} minutos`;

  try {
    const result = await resend.emails.send({
      from: FROM_EMAIL,
      to: opts.to,
      subject: `⏰ Lembrete: sua aula começa em ${label} — ${opts.subject}`,
      html: `
        <div style="font-family:sans-serif;max-width:520px;margin:0 auto;padding:24px;background:#f6faf7;border-radius:12px">
          <h2 style="color:#1d7a45;margin:0 0 16px">⏰ Sua aula começa em ${label}!</h2>
          <table style="width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden">
            <tr><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-size:13px;color:#666">Professor</td><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-weight:600">${opts.professorName}</td></tr>
            <tr><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-size:13px;color:#666">Disciplina</td><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-weight:600">${opts.subject}</td></tr>
            <tr><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-size:13px;color:#666">Turma</td><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-weight:600">${opts.classGroup}</td></tr>
            <tr><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-size:13px;color:#666">Sala</td><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-weight:600">${opts.roomName}</td></tr>
            <tr><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-size:13px;color:#666">Data</td><td style="padding:10px 16px;border-bottom:1px solid #e2f0e8;font-weight:600">${opts.date}</td></tr>
            <tr><td style="padding:10px 16px;font-size:13px;color:#666">Horário</td><td style="padding:10px 16px;font-weight:600">${opts.startTime} – ${opts.endTime}</td></tr>
          </table>
          <p style="margin:20px 0 0;font-size:13px;color:#888">Confirme sua presença no sistema após o início da aula.</p>
          <p style="margin:8px 0 0;font-size:11px;color:#bbb">ClickReserva — C.E. Prof. Mário B.T. Braga</p>
        </div>
      `,
    });

    if (result.error) {
      return { ok: false, error: JSON.stringify(result.error) };
    }
    return { ok: true };
  } catch (err: any) {
    return { ok: false, error: err?.message ?? String(err) };
  }
}
